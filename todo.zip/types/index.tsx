type TodoProps = {
  todo: string;
  details: string;
};
